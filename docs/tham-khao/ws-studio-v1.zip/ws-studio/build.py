#!/usr/bin/env python3
"""Bundle src/ into a single self-contained dist/ws-studio.html (no CDN, works via file://)."""
import pathlib, re, sys
root = pathlib.Path(__file__).parent
src = root / 'src'
# Thứ tự lớp (đặc tả mục 4). Mỗi tệp trong src/ phải có tên ở đây hoặc trong CSS/VIEWER, thiếu là dừng.
LAYERS = [
    ('dữ liệu',   ['data.js']),
    ('lõi',       ['core.js']),
    ('miền',      ['validator.js', 'mockai.js', 'rules.js', 'importers.js', 'seed.js', 'export.js']),
    ('giao diện', ['ui.js', 'actions.js']),
    ('màn hình',  ['views-home.js', 'views-wizard.js', 'views-editor.js', 'views-library.js', 'views-review.js', 'views-admin.js']),
    ('khởi động', ['app.js']),
]
CSS = ['fonts.css', 'app.css', 'viewer.css']
VIEWER = 'viewer.js'
order = [f for _, fs in LAYERS for f in fs]
listed = set(order) | set(CSS) | {VIEWER}
on_disk = {p.name for p in src.iterdir() if p.suffix in ('.js', '.css')}
if on_disk - listed: sys.exit(f'ERROR: chưa xếp lớp: {sorted(on_disk - listed)}')
if listed - on_disk: sys.exit(f'ERROR: thiếu tệp: {sorted(listed - on_disk)}')
parts = []
for f in order:
    t = (src / f).read_text(encoding='utf-8')
    if re.search(r'</script', t, re.I):
        sys.exit(f'ERROR: {f} contains a literal </script')
    parts.append(f'/* ===== {f} ===== */\n' + t)
viewer = (src/VIEWER).read_text(encoding='utf-8')
if re.search(r'</script', viewer, re.I): sys.exit('ERROR: viewer.js contains </script')
html = f'''<!doctype html>
<html lang="vi"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>ws-studio · Prototype soạn phiếu bài tập</title>
<meta name="description" content="Prototype MVP ws-studio: soạn, duyệt hai cấp và xuất phiếu bài tập HTML tương tác. Dữ liệu mô phỏng.">
<style id="ws-fonts">{(src/'fonts.css').read_text(encoding='utf-8')}</style>
<style>{(src/'app.css').read_text(encoding='utf-8')}</style>
<style id="wsv-css">{(src/'viewer.css').read_text(encoding='utf-8')}</style>
</head><body><div id="app"><div style="padding:40px;font-family:system-ui">Đang tải ws-studio…</div></div>
<noscript>ws-studio cần bật JavaScript.</noscript>
<script id="wsv-js">{viewer}</script>
<script>
{chr(10).join(parts)}
</script></body></html>'''
out = root/'dist'/'ws-studio.html'
out.write_text(html, encoding='utf-8')
print('built', out, round(len(html.encode())/1024), 'KB')
