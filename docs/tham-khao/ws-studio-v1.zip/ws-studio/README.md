# ws-studio · MVP prototype

Bản dựng chạy độc lập: `dist/ws-studio.html` (bấm đúp để mở, không cần máy chủ, không CDN).

## Cấu trúc mã nguồn (`src/`)

Thứ tự lớp đúng mục 4 của đặc tả; `build.py` khai báo các lớp trong `LAYERS` và dừng nếu có tệp chưa được xếp lớp (D-123). Màn hình chỉ vẽ và gọi hành động, logic miền nằm ở lớp miền (D-121).

| Tệp | Vai trò |
|---|---|
| `app.css` | Token thiết kế và giao diện app |
| `fonts.css` | Be Vietnam Pro nhúng base64 (sinh bằng `tools/fetch_fonts.py`, cần mạng một lần) |
| `viewer.css`, `viewer.js` | Viewer dùng chung cho preview trong app và tệp HTML xuất ra |
| `data.js` | Giáo trình mẫu, theme, tiêu chuẩn, bố cục, người dùng |
| `core.js` | Tiện ích, store, lưu `localStorage` (`wsstudio.v1`), nhật ký, thông báo |
| `validator.js` | Bộ kiểm tra V01–V17, điểm 6 tiêu chí, tuân thủ cấp phiếu |
| `mockai.js` | Sinh bài giả lập theo hạt giống, theme, tự sửa, ép lỗi, dàn khối, media giả lập |
| `rules.js` | Quyền, máy trạng thái bài và phiếu, khóa mềm, tiến độ lesson cho Dashboard |
| `importers.js` | Đọc giáo trình Markdown (Phụ lục A.1), xuất ngược ra Markdown, kiểm tệp kiến thức/skill của lesson (D-112) |
| `seed.js` | Dữ liệu mẫu: 10 phiếu (7 kịch bản + 3 trình diễn), kho bài |
| `export.js` | Dựng 2 tệp HTML (giáo viên / học sinh), kiểm tra xuất bản, JSON |
| `ui.js`, `actions.js` | Thành phần giao diện (kể cả so sánh văn bản bài); mọi thay đổi trạng thái |
| `views-home.js` | Dashboard, Phiếu, Giáo trình, Tiêu chuẩn, Nhật ký, Phản hồi, Cài đặt |
| `views-wizard.js` | Soạn phiếu 4 bước đầu và chạy sinh bài |
| `views-editor.js` | Trình soạn phiếu, soạn từng bài, chế độ duyệt |
| `views-library.js` | Kho bài, chọn bài từ kho |
| `views-review.js` | Duyệt Phiếu, Viewer, hộp Tải bản chính thức, đẩy API giả lập |
| `views-admin.js` | Cấu hình hệ thống (Admin) |
| `app.js` | Vỏ app, router, bảng demo, `selfTest()` |

## Dựng và kiểm thử

```bash
python3 build.py                 # gộp src/ thành dist/ws-studio.html
cd tests && python3 run_all.py  # chạy t1…t8, cộng số kiểm tra và so với 259
python3 t1_shell.py              # hoặc chạy riêng một bộ (cần Playwright + Chromium; đặt WS_CHROME nếu cần trỏ tới trình duyệt riêng)
```

| Bộ kiểm thử | Nội dung | Số kiểm tra |
|---|---|---|
| t1_shell | Khung, store, seed, dashboard, selfTest | 28 |
| t2_wizard | Tạo phiếu 4 bước, sinh giả lập, ép lỗi (S2) | 22 |
| t3_editor | Trình soạn, inline lỗi, quick fix, tạo lại, so sánh, hoàn tác | 45 |
| t4_flow | S1 bước 1–8, S3, S4, S5, BR-17 | 42 |
| t5_viewer | Xuất 2 tệp, mở ngoại tuyến, S6 đầy đủ | 66 |
| t6_admin | Cấu hình hệ thống, phản hồi, a11y, màn hẹp | 33 |
| t7_ui | Icon SVG, aria-label, dark mode, thanh trên trình soạn, tab bar điện thoại (D-114…D-118) | 18 |
| t8_contrast | Font nhúng và đo tương phản WCAG AA, 12 màn hình, sáng và tối (D-120) | 5 |

## Hệ giao diện (D-114…D-118)

- **Token:** `app.css` (`:root`, khối DARK) và `viewer.css` (`.wsv`). Màu, bóng, bo góc đều đi qua biến CSS; không viết mã màu trực tiếp trong thành phần.
- **Icon:** `viewer.js` giữ bộ icon SVG nét (`WSV.ic`) và tự đổi ký tự/emoji biểu tượng trong giao diện thành SVG (`WSV.autoIconize`); nội dung phiếu (`.wsv-content`, `.wsx`) không bị đổi. Nút chỉ có icon tự nhận `aria-label` từ `title`.
- **Dark mode:** theo hệ thống, hoặc chọn ở Cài đặt (lưu `localStorage` khóa `wsstudio.theme`, không nằm trong dữ liệu app). Tờ phiếu và tệp xuất luôn nền sáng.
- **Điện thoại (≤767px):** tab bar đáy cho Dashboard, Phiếu, Soạn, Kho bài, Khác; trình soạn vẫn dành cho màn rộng.
